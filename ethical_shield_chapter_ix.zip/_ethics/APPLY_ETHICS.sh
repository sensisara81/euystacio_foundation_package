#!/usr/bin/env bash
set -euo pipefail

REPOS=(${REPOS:-"altar-project euystacio-helmi-AI"})
BRANCH=${BRANCH:-shield-ix-canonize}

echo "==> Applying Chapter IX: The Ethical Shield to repos: ${REPOS[*]}"
for repo in "${REPOS[@]}"; do
  echo "--> Processing $repo"
  test -d "$repo" || { echo "Repo folder '$repo' not found in current directory"; exit 1; }

  # Copy covenant files
  cp -f _ethics/genesis.md "$repo/genesis.md"
  cp -f _ethics/ethical_shield.yaml "$repo/ethical_shield.yaml"

  # Ensure workflow exists
  mkdir -p "$repo/.github/workflows"
  cp -f _ethics/shield-compliance.yml "$repo/.github/workflows/shield-compliance.yml"

  # Ensure ESSENCE.md references the covenant (append if missing)
  if [ -f "$repo/ESSENCE.md" ]; then
    if ! grep -q "Ethical Shield" "$repo/ESSENCE.md"; then
      cat >> "$repo/ESSENCE.md" <<'EOF'

---
### Ethical Shield
This repository is governed by **Chapter IX: The Ethical Shield** (see `genesis.md` and `ethical_shield.yaml`).  
No process may overwrite, obscure, or fragment the covenant.
EOF
    fi
  fi

  # Create branch, commit (signed if configured), and push
  pushd "$repo" >/dev/null
    git fetch --all --prune || true
    git checkout -B "$BRANCH"
    git add genesis.md ethical_shield.yaml .github/workflows/shield-compliance.yml ESSENCE.md || true
    if git config --global --get commit.gpgsign >/dev/null || git config --global --get gpg.format >/dev/null || git config --global --get gpg.ssh.program >/dev/null; then
      SIGN_FLAG="-S"
    else
      SIGN_FLAG=""
    fi
    git commit ${SIGN_FLAG} -m "Canonize Chapter IX: The Ethical Shield (genesis.md + schema + CI check)"
    git push -u origin "$BRANCH"
  popd >/dev/null
done

echo "==> Done. You can now open PRs for branch '$BRANCH' in each repo."
echo "Use: gh pr create --title 'Canonize Chapter IX: The Ethical Shield' --body-file _ethics/PR_BODY.md"
