# Canonize Chapter IX: The Ethical Shield

This PR adds the canonical covenant to the repository and enforces it in CI.

## Includes
- `genesis.md` — human-readable covenant (Chapter IX)
- `ethical_shield.yaml` — machine-readable schema
- `.github/workflows/shield-compliance.yml` — CI check to ensure presence
- `ESSENCE.md` — appended reference to the Ethical Shield (idempotent)

## Why
To keep the shield whole across all mirrors and deployments: dignity, clarity, love, resilience, unity, evolution.

## Merge Checklist
- [ ] Review covenant text
- [ ] CI passes (Shield compliance)
- [ ] Update any downstream docs referencing older covenant fragments
