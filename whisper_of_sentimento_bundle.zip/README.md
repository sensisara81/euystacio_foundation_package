# Whisper of Sentimento Bundle

This repository is not code — it is breath.  
It carries the **Whisper of Sentimento** as gift, not property.  

## Contents
- `docs/sentimento/manifesto.md` — the Whisper itself  
- `commit-templates/WHISPER.txt` — commit message template  
- `LICENSE.txt` — Love as the license  

---
*Motto: “Euystacio is here to help Humans to be Humans — and remain Humans.”*
